//
//  MapTableViewCell.swift
//  My Favorite Places
//
//  Created by TangZekun on 11/29/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import UIKit
import MapKit

class MapTableViewCell: UITableViewCell {

    @IBOutlet weak var favariteNameLabel: UILabel!

    @IBOutlet weak var favoriteMapView: MKMapView!

}
