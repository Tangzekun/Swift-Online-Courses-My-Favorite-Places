//
//  Favorite.swift
//  My Favorite Places
//
//  Created by TangZekun on 11/28/15.
//  Copyright © 2015 TangZekun. All rights reserved.
//

import Foundation
import CoreData


class Favorite: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
